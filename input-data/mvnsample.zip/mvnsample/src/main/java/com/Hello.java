package com;


public class Hello  {

    public static void main( String[] args ) throws Exception
    {
        System.out.println("</SUCCESS>");
    }
}
