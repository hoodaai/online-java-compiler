package com;


/**
 * This code contains error
 */
public Class Application {

      public static void main( String[] args ) throws Exception
      {
            System.out.println("</SUCCESS>");
      }
}
