package com;


/**
 * This code contains error
 */
public class Hello  {

    public static void main( String[] args ) throws Exception
    {
        system.out.println("</SUCCESS>");
    }
}
