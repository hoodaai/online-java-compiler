package com;


pppublic class Hello  {

    public static void main( String[] args ) throws Exception
    {
System.out.println("</SUCCESS>");
    }
}
